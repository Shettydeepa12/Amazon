# Gui-flipkart
Automation with selenium for flipkart 
click to visit website: https://shettydeepa12.github.io/Gui-flipkart/
